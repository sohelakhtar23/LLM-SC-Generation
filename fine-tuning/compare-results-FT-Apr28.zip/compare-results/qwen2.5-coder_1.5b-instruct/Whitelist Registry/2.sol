// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    // Mapping to keep track of addresses in the whitelist
    mapping(address => bool) public isWhitelisted;

    // Address of the owner
    address private _owner;

    // Event emitted when an address is added to the whitelist
    event AddressAdded(address indexed addr);

    // Event emitted when an address is removed from the whitelist
    event AddressRemoved(address indexed addr);

    /**
     * Constructor sets the deployer as the owner
     */
    constructor() {
        _owner = msg.sender;
    }

    /**
     * @dev Adds an address to the whitelist
     * @param addr The address to add to the whitelist
     */
    function addToWhitelist(address addr) public onlyOwner {
        require(addr != address(0), "Cannot add zero address");
        isWhitelisted[addr] = true;
        emit AddressAdded(addr);
    }

    /**
     * @dev Removes an address from the whitelist
     * @param addr The address to remove from the whitelist
     */
    function removeFromWhitelist(address addr) public onlyOwner {
        require(isWhitelisted[addr], "Address not found in whitelist");
        isWhitelisted[addr] = false;
        emit AddressRemoved(addr);
    }

    /**
     * @dev Checks if an address is whitelisted
     * @param addr The address to check
     * @return true if the address is whitelisted, false otherwise
     */
    function isAddressWhitelisted(address addr) public view returns (bool) {
        return isWhitelisted[addr];
    }

    /**
     * @dev Restricts add and remove functions to owner only
     */
    modifier onlyOwner() {
        require(msg.sender == _owner, "Only the owner can call this function");
        _;
    }
}