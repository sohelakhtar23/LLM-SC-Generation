// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    // Mapping to track whitelist status of addresses
    mapping(address => bool) public isWhitelisted;

    // Address of the owner
    address private _owner;

    /**
     * @notice Constructor sets the deployer as the owner.
     */
    constructor() {
        _owner = msg.sender;
    }

    /**
     * @notice Adds an address to the whitelist.
     * @param _address The address to be added to the whitelist.
     * @dev Only the owner can add addresses to the whitelist.
     * @event AddressAdded(address indexed addr)
     */
    function addAddressToWhitelist(address _address) public onlyOwner {
        require(_address != address(0), "Cannot add zero address");
        isWhitelisted[_address] = true;
        emit AddressAdded(_address);
    }

    /**
     * @notice Removes an address from the whitelist.
     * @param _address The address to be removed from the whitelist.
     * @dev Only the owner can remove addresses from the whitelist.
     * @event AddressRemoved(address indexed addr)
     */
    function removeAddressFromWhitelist(address _address) public onlyOwner {
        require(isWhitelisted[_address], "Address is not whitelisted");
        isWhitelisted[_address] = false;
        emit AddressRemoved(_address);
    }

    /**
     * @notice Checks if an address is whitelisted.
     * @param _address The address to check.
     * @return true if the address is whitelisted, otherwise false.
     */
    function isAddressWhitelisted(address _address) public view returns (bool) {
        return isWhitelisted[_address];
    }

    /**
     * @notice Restricts add and remove functions to owner only.
     */
    modifier onlyOwner() {
        require(msg.sender == _owner, "Only the owner can call this function");
        _;
    }
}