// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    // Mapping to track whether an address is whitelisted
    mapping(address => bool) public whitelist;

    // Address of the owner
    address private _owner;

    // Event emitted when an address is added to the whitelist
    event AddressAdded(address indexed addr);

    // Event emitted when an address is removed from the whitelist
    event AddressRemoved(address indexed addr);

    /**
     * @dev Constructor sets the initial owner.
     */
    constructor() {
        _owner = msg.sender;
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        require(msg.sender == _owner, "Only the owner can call this function");
        _;
    }

    /**
     * @dev Adds an address to the whitelist.
     *
     * @param addr The address to add to the whitelist.
     */
    function addAddress(address addr) public onlyOwner {
        require(addr != address(0), "Cannot add zero address to the whitelist");
        whitelist[addr] = true;
        emit AddressAdded(addr);
    }

    /**
     * @dev Removes an address from the whitelist.
     *
     * @param addr The address to remove from the whitelist.
     */
    function removeAddress(address addr) public onlyOwner {
        require(whitelist[addr], "Address is not whitelisted");
        whitelist[addr] = false;
        emit AddressRemoved(addr);
    }

    /**
     * @dev Returns whether an address is whitelisted.
     *
     * @param addr The address to check.
     * @return bool Whether the address is whitelisted.
     */
    function isWhitelisted(address addr) public view returns (bool) {
        return whitelist[addr];
    }
}