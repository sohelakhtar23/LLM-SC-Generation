// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    // Mapping to track whether an address is whitelisted
    mapping(address => bool) public whitelist;

    // Address of the owner
    address private _owner;

    // Event emitted when an address is added to the whitelist
    event AddedToWhitelist(address indexed address);

    // Event emitted when an address is removed from the whitelist
    event RemovedFromWhitelist(address indexed address);

    /**
     * @dev Constructor sets the deployer as the owner.
     */
    constructor() {
        _owner = msg.sender;
    }

    /**
     * @dev Adds an address to the whitelist if it's not already whitelisted and the sender is the owner.
     * @param address The address to be added to the whitelist.
     */
    function addAddressToWhitelist(address address) public onlyOwner {
        require(address != address(0), "Cannot add zero address");
        require(!whitelist[address], "Address already whitelisted");

        whitelist[address] = true;
        emit AddedToWhitelist(address);
    }

    /**
     * @dev Removes an address from the whitelist if it's whitelisted and the sender is the owner.
     * @param address The address to be removed from the whitelist.
     */
    function removeAddressFromWhitelist(address address) public onlyOwner {
        require(whitelist[address], "Address not whitelisted");

        whitelist[address] = false;
        emit RemovedFromWhitelist(address);
    }

    /**
     * @dev Checks if an address is whitelisted.
     * @param address The address to check.
     * @return bool Whether the address is whitelisted.
     */
    function isAddressInWhitelist(address address) public view returns (bool) {
        return whitelist[address];
    }

    /**
     * @dev Restricts add and remove functions to owner only.
     */
    modifier onlyOwner() {
        require(msg.sender == _owner, "Only the owner can call this function");
        _;
    }
}