// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;

    event Deposit(address indexed from, uint256 value);
    event CheckIn(address indexed by, uint256 timestamp);
    event Claim(address indexed by, uint256 timestamp);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be the zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");

        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }

    function deposit() public payable {
        emit Deposit(msg.sender, msg.value);
    }

    function checkIn() public {
        uint256 currentTime = block.timestamp;
        require(currentTime - lastCheckIn > inactivityTimeout, "Not enough time has passed since the last check-in");

        // Reset the inactivity timer
        lastCheckIn = currentTime;

        emit CheckIn(msg.sender, currentTime);
    }

    function claim() public {
        uint256 currentTime = block.timestamp;
        require(currentTime - lastCheckIn > inactivityTimeout, "Not enough time has passed since the last check-in");

        // Transfer funds to beneficiary
        require(beneficiary != address(0), "Beneficiary cannot be the zero address");
        require(msg.value == 0, "Cannot claim more than the deposited amount");

        payable(beneficiary).transfer(msg.value);

        emit Claim(msg.sender, currentTime);
    }

    uint256 private lastCheckIn;

    modifier onlyOwner() {
        require(msg.sender == owner(), "Only the owner can call this function");
        _;
    }
}