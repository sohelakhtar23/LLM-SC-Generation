// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;

    event Deposit(address indexed sender, uint256 amount);
    event CheckIn(address indexed owner);
    event Claim(address indexed beneficiary, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be the zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");

        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }

    function deposit() public payable {
        emit Deposit(msg.sender, msg.value);
    }

    modifier onlyOwner() {
        require(msg.sender == owner(), "Only the owner can call this function");
        _;
    }

    function checkIn() public onlyOwner {
        emit CheckIn(msg.sender);
    }

    function claim() public {
        require(block.timestamp - lastCheckIn > inactivityTimeout, "Claim attempt before inactivity period has elapsed");

        uint256 balance = address(this).balance;
        require(balance > 0, "Contract is empty and cannot be claimed");

        payable(beneficiary).transfer(balance);
        emit Claim(beneficiary, balance);
    }

    function owner() public view returns (address) {
        return msg.sender;
    }

    uint256 private lastCheckIn;

    modifier checkInAfterLastCheckIn() {
        require(block.timestamp - lastCheckIn > inactivityTimeout, "Claim attempt before inactivity period has elapsed");
        _;
    }
}