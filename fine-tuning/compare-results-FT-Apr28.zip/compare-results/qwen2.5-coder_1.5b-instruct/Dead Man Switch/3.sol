// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool public isActive = true;
    event CheckIn(address indexed from);
    event Deposit(address indexed from, uint256 amount);
    event Claim(address indexed from, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be the zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");
        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }

    function checkIn() public {
        isActive = true;
        emit CheckIn(msg.sender);
    }

    function deposit(uint256 amount) public payable {
        require(isActive, "Contract is inactive");
        require(amount > 0, "Deposit must be greater than zero");
        emit Deposit(msg.sender, amount);
    }

    function claim() public {
        if (block.timestamp - lastCheckIn < inactivityTimeout) {
            revert("Claim attempt before inactivity period has elapsed");
        }
        isActive = false;
        uint256 balance = address(this).balance;
        require(balance > 0, "Contract is empty");
        payable(beneficiary).transfer(balance);
        emit Claim(msg.sender, balance);
    }

    // Optional: Track the last check-in time
    uint256 public lastCheckIn;

    modifier onlyOwner() {
        require(msg.sender == owner(), "Only the owner can call this function");
        _;
    }
}