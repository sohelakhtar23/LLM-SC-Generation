// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool public isOwnerActive = true;

    event OwnerCheckIn(address indexed owner);
    event Deposit(address indexed sender, uint256 amount);
    event Claim(address indexed beneficiary);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be the zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");
        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }

    function checkIn() public {
        if (!isOwnerActive) revert("Owner is inactive");

        emit OwnerCheckIn(msg.sender);
    }

    function deposit(uint256 amount) public payable {
        require(isOwnerActive, "Owner must be active");
        emit Deposit(msg.sender, amount);
    }

    function claim() public {
        if (block.timestamp - lastCheckIn < inactivityTimeout) revert("Claim attempt before inactivity period");

        uint256 balance = address(this).balance;
        require(balance > 0, "Contract has no funds to claim");

        isOwnerActive = false;
        emit Claim(beneficiary);

        payable(beneficiary).transfer(balance);
    }

    function getLastCheckIn() public view returns (uint256) {
        return lastCheckIn;
    }
}