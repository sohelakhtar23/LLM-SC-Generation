// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    // Mapping to keep track of donations by each address
    mapping(address => uint256) public donationsByAddress;
    
    // Counter for the total number of unique donors
    uint256 public donorCount;
    
    // Total amount donated
    uint256 public totalDonations;
    
    // Campaign title set at deployment
    string public campaignTitle;

    // Event to log each donation
    event Donation(address indexed donor, uint256 amount);

    // Event to log each withdrawal
    event Withdrawal(address indexed beneficiary, uint256 amount);

    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
    }

    function donate() public payable {
        require(msg.value > 0, "Donation must be greater than zero");
        
        donationsByAddress[msg.sender] += msg.value;
        totalDonations += msg.value;
        donorCount++;
        
        emit Donation(msg.sender, msg.value);
    }

    function withdraw() public onlyBeneficiary {
        require(totalDonations > 0, "No funds to withdraw");
        
        uint256 amountToWithdraw = totalDonations;
        totalDonations = 0;
        donorCount = 0;
        
        // Emit event for withdrawal
        emit Withdrawal(msg.sender, amountToWithdraw);
        
        // Transfer the balance to the beneficiary
        payable(msg.sender).transfer(amountToWithdraw);
    }

    function getDonationByAddress(address _address) public view returns (uint256) {
        return donationsByAddress[_address];
    }

    function getTotalDonations() public view returns (uint256) {
        return totalDonations;
    }

    function getDonorCount() public view returns (uint256) {
        return donorCount;
    }
}