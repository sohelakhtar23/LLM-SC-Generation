// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    string public campaignTitle;
    mapping(address => uint256) public donations;
    uint256 public totalDonations;
    uint256 public uniqueDonors;
    address public beneficiary;

    constructor(string memory _campaignTitle, address _beneficiary) {
        campaignTitle = _campaignTitle;
        beneficiary = _beneficiary;
    }

    function donate() external payable {
        require(msg.value > 0, "Donation amount must be greater than zero");
        donations[msg.sender] += msg.value;
        totalDonations += msg.value;
        uniqueDonors++;
    }

    function withdraw() public onlyBeneficiary {
        require(address(this).balance > 0, "Contract balance is zero");
        bool success = payable(beneficiary).transfer(address(this).balance);
        if (!success) revert("Transfer failed");
        emit Withdrawal(msg.sender, address(this).balance);
    }

    event Donation(address indexed donor, uint256 amount);
    event Withdrawal(address indexed donor, uint256 amount);

    modifier onlyBeneficiary() {
        require(msg.sender == beneficiary, "Only the beneficiary can withdraw");
        _;
    }
}