// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    // Mapping to store donations by each address
    mapping(address => uint256) public donations;
    
    // Counter for unique donors
    uint256 public donorCount;
    
    // Total amount donated
    uint256 public totalDonations;
    
    // Beneficiary address
    address public beneficiary;
    
    // Campaign title string at deployment
    string private campaignTitle;

    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
        beneficiary = msg.sender; // The deployer becomes the beneficiary
    }

    function donate() external payable {
        require(msg.value > 0, "Donation amount must be greater than zero");
        
        donations[msg.sender] += msg.value;
        totalDonations += msg.value;
        donorCount++;
        
        emit Donation(msg.sender, msg.value);
    }

    function withdraw() public onlyBeneficiary {
        require(totalDonations > 0, "No funds to withdraw");
        
        bool success = payable(beneficiary).transfer(totalDonations);
        if (!success) {
            revert("Failed to transfer funds");
        }
        
        totalDonations = 0;
        donorCount = 0;
        
        emit Withdrawal(msg.sender, totalDonations);
    }

    function getDonation(address _address) public view returns (uint256) {
        return donations[_address];
    }

    function getTotalDonations() public view returns (uint256) {
        return totalDonations;
    }

    function getDonorCount() public view returns (uint256) {
        return donorCount;
    }

    modifier onlyBeneficiary() {
        require(msg.sender == beneficiary, "Only the beneficiary can withdraw");
        _;
    }
}