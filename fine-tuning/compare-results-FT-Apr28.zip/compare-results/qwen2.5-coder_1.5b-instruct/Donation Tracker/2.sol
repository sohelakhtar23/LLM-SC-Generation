// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    // Mapping to store donations by address
    mapping(address => uint256) public donationsByAddress;
    // Total number of unique donors
    uint256 public totalDonors;
    // Overall total donations received
    uint256 public totalDonations;
    // Campaign title string at deployment
    string public campaignTitle;

    // Event for each donation
    event Donation(address indexed donor, uint256 amount);
    // Event for each withdrawal
    event Withdrawal(address indexed beneficiary, uint256 amount);

    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
    }

    function donate() public payable {
        require(msg.value > 0, "Donation must be greater than zero");
        donationsByAddress[msg.sender] += msg.value;
        totalDonations += msg.value;
        totalDonors++;
        emit Donation(msg.sender, msg.value);
    }

    function withdraw() public onlyBeneficiary {
        require(totalDonations > 0, "No funds to withdraw");
        uint256 amountToWithdraw = totalDonations;
        totalDonations = 0;
        totalDonors = 0;
        payable(msg.sender).transfer(amountToWithdraw);
        emit Withdrawal(msg.sender, amountToWithdraw);
    }

    function getDonationByAddress(address _address) public view returns (uint256) {
        return donationsByAddress[_address];
    }

    function getTotalDonations() public view returns (uint256) {
        return totalDonations;
    }

    function getDonorCount() public view returns (uint256) {
        return totalDonors;
    }

    modifier onlyBeneficiary() {
        require(msg.sender == beneficiary, "Only the beneficiary can withdraw");
        _;
    }
}