// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    // Mapping to store recipient addresses and their respective shares
    mapping(address => uint) public recipients;
    // Array of recipient addresses
    address[] public recipientAddresses;
    // Total share value
    uint public totalShareValue = 0;

    /**
     * Constructor to initialize the contract with a list of recipients and their shares.
     */
    constructor(address[] memory _recipientAddresses, uint[] memory _shares) {
        require(_recipientAddresses.length > 0, "Recipient list cannot be empty");
        for (uint i = 0; i < _recipientAddresses.length; i++) {
            require(_recipientAddresses[i] != address(0), "Zero address is not allowed as a recipient");
            recipients[_recipientAddresses[i]] = _shares[i];
            totalShareValue += _shares[i];
        }
    }

    /**
     * Public payable function to split incoming Ether payments.
     */
    function split() public payable {
        require(msg.value > 0, "No Ether was sent for splitting");

        // Calculate the amount each recipient should receive
        uint sharePerRecipient = msg.value.mul(totalShareValue).div(100);

        // Distribute the received Ether to each recipient
        for (uint i = 0; i < recipientAddresses.length; i++) {
            recipients[recipientAddresses[i]] += sharePerRecipient;
            emit SplitEvent(msg.sender, sharePerRecipient);
        }

        // Send any remaining dust to the first recipient
        if (msg.value > totalShareValue) {
            recipients[recipientAddresses[0]] += msg.value.sub(totalShareValue);
            emit SplitEvent(msg.sender, msg.value.sub(totalShareValue));
        }
    }

    /**
     * Public view function to retrieve the list of recipients and their shares.
     */
    function getRecipients() public view returns (address[] memory, uint[] memory) {
        return (recipientAddresses, recipients.values());
    }

    /**
     * Event emitted for each split transaction.
     */
    event SplitEvent(address sender, uint amount);
}