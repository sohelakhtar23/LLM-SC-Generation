// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    // Mapping to store recipient addresses and their shares
    mapping(address => uint256) public recipients;
    // List of all recipients
    address[] public recipientList;
    // Total amount received so far
    uint256 public totalReceived = 0;

    /**
     * Constructor to initialize the contract with a list of recipients and their shares.
     */
    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0, "Recipient list cannot be empty");
        for (uint256 i = 0; i < _recipients.length; i++) {
            require(_recipients[i] != address(0), "Zero address is not allowed as a recipient");
            recipients[_recipients[i]] = _shares[i];
            recipientList.push(_recipients[i]);
        }
        // Calculate the sum of all shares
        uint256 totalShareSum = 0;
        for (uint256 i = 0; i < recipientList.length; i++) {
            totalShareSum += recipients[recipientList[i]];
        }
        require(totalShareSum == 100, "Shares must sum to exactly 100");
    }

    /**
     * Function to split the received Ether among the recipients.
     */
    function split() public payable {
        require(msg.value > 0, "No Ether was sent");

        // Calculate the amount each recipient should receive
        uint256 share = msg.value * (recipients[msg.sender] / totalShareSum);
        // Add the share to the total received
        totalReceived += share;

        // Send the share to the recipient
        payable(msg.sender).transfer(share);

        // Emit an event for each split
        emit Split(msg.sender, share);
    }

    /**
     * Public view function to retrieve the list of recipients and their shares.
     */
    function getRecipients() public view returns (address[] memory, uint256[] memory) {
        return (recipientList, recipients);
    }

    /**
     * Event emitted when a split is made.
     */
    event Split(address sender, uint256 amount);
}