// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    // Mapping to store recipient addresses and their shares
    mapping(address => uint256) public recipientShares;
    // List of all recipients
    address[] public recipients;
    // Total share sum
    uint256 public totalShareSum = 0;

    /**
     * Constructor to initialize the contract with a list of recipients and their shares.
     */
    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0, "Recipient list must not be empty");
        require(_shares.length == _recipients.length, "Share array length must match recipient array length");

        for (uint256 i = 0; i < _recipients.length; i++) {
            recipients.push(_recipients[i]);
            totalShareSum += _shares[i];
        }

        // Validate that no recipient address is the zero address
        require(totalShareSum > 0, "Total share sum must be greater than zero");
    }

    /**
     * Public payable function to split incoming Ether payments among the recipients.
     */
    function split() public payable {
        require(msg.value > 0, "Cannot send zero Ether");

        // Calculate the amount each recipient should receive
        uint256 amountPerRecipient = msg.value.mul(100).div(totalShareSum);

        // Distribute the received Ether to each recipient proportional to their share
        for (uint256 i = 0; i < recipients.length; i++) {
            recipientShares[recipients[i]] += amountPerRecipient;
        }

        // Send any remaining dust to the first recipient
        uint256 remainder = msg.value.mod(totalShareSum);
        if (remainder > 0) {
            recipientShares[recipients[0]] += remainder;
        }

        // Emit an event for each split including the sender address and total amount distributed
        emit SplitEvent(msg.sender, msg.value);

        // Transfer any remaining dust to the first recipient
        payable(recipients[0]).transfer(remainder);
    }

    /**
     * Public view function to retrieve the list of recipients.
     */
    function getRecipients() public view returns (address[] memory) {
        return recipients;
    }

    /**
     * Public view function to retrieve the shares of a specific recipient.
     */
    function getRecipientShare(address recipient) public view returns (uint256) {
        return recipientShares[recipient];
    }

    /**
     * Event emitted when Ether is split among recipients.
     */
    event SplitEvent(address sender, uint256 amount);
}