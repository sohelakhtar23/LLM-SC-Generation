// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    // Mapping to store recipient addresses and their respective shares
    mapping(address => uint256) public recipientShares;
    
    // List of all recipients
    address[] public recipients;
    
    // Event emitted when a split is performed
    event SplitPerformed(
        address indexed sender,
        uint256 amountDistributed
    );
    
    /**
     * Constructor to initialize the contract with recipient addresses and their shares.
     */
    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0, "Recipient list cannot be empty");
        
        // Validate each share is less than or equal to 100%
        for (uint256 i = 0; i < _shares.length; i++) {
            require(_shares[i] <= 100, "Share must not exceed 100%");
        }
        
        // Calculate the total sum of shares
        uint256 totalShares = 0;
        for (uint256 i = 0; i < _shares.length; i++) {
            totalShares += _shares[i];
        }
        
        // Validate that the total shares sum to exactly 100%
        require(totalShares == 100, "Sum of shares must be exactly 100%");
        
        // Store recipient addresses and their respective shares
        for (uint256 i = 0; i < _recipients.length; i++) {
            recipients.push(_recipients[i]);
            recipientShares[_recipients[i]] = _shares[i];
        }
    }
    
    /**
     * Public payable function to split incoming Ether payments.
     */
    function split() public payable {
        require(msg.value > 0, "Cannot send zero Ether");
        
        // Calculate the total amount of Ether received
        uint256 totalAmount = msg.value;
        
        // Calculate the amount each recipient should receive
        uint256[] memory sharesToDistribute = new uint256[](recipients.length);
        for (uint256 i = 0; i < recipients.length; i++) {
            sharesToDistribute[i] = (totalAmount * recipientShares[recipients[i]]) / 100;
        }
        
        // Send the Ether to each recipient
        for (uint256 i = 0; i < recipients.length; i++) {
            require(recipientShares[recipients[i]] > 0, "Recipient has zero share");
            
            uint256 amountToDistribute = sharesToDistribute[i];
            if (amountToDistribute > 0) {
                payable(recipients[i]).transfer(amountToDistribute);
                
                // Emit the split event
                emit SplitPerformed(msg.sender, amountToDistribute);
            }
        }
        
        // Send any remaining dust to the first recipient
        uint256 dust = totalAmount - (totalShares * totalAmount) / 100;
        if (dust > 0) {
            payable(recipients[0]).transfer(dust);
            
            // Emit the split event for dust
            emit SplitPerformed(msg.sender, dust);
        }
    }
    
    /**
     * Public view function to retrieve the list of recipients and their shares.
     */
    function getRecipientsAndShares() public view returns (address[] memory, uint256[] memory) {
        return (recipients, recipientShares);
    }
}