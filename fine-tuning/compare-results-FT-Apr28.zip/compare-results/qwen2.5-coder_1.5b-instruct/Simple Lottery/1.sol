// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract Lottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address public winner;
    uint256 public prizeAmount;

    constructor(uint256 _ticketPrice) {
        require(_ticketPrice > 0, "Ticket price must be greater than zero");
        ticketPrice = _ticketPrice;
        manager = msg.sender;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Invalid ticket price");
        participants[msg.sender] = true;
    }

    modifier onlyManager() {
        require(msg.sender == manager, "Only the manager can call this function");
        _;
    }

    function pickWinner() public onlyManager returns (bool) {
        require(participants.length > 0, "No participants have entered the lottery");

        uint256 randomIndex = uint256(keccak256(blockhash(block.number - 1))) % participants.length;
        winner = participants[randomIndex];
        prizeAmount = address(this).balance;

        emit WinnerPicked(winner, prizeAmount);

        // Reset participants list
        participants = mapping(address => bool)(true);
        return true;
    }

    event WinnerPicked(address winner, uint256 prizeAmount);
}