// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract Lottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address public winner;
    uint256 public prizeAmount;

    constructor(uint256 _ticketPrice) {
        require(_ticketPrice > 0, "Ticket price must be greater than zero");
        manager = msg.sender;
        ticketPrice = _ticketPrice;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Invalid ticket price");
        participants[msg.sender] = true;
    }

    modifier onlyManager() {
        require(msg.sender == manager, "Only the manager can call this function");
        _;
    }

    function pickWinner() public onlyManager returns (bool) {
        if (!participants[msg.sender]) {
            emit NoParticipantsError();
            return false;
        }
        winner = msg.sender;
        prizeAmount = address(this).balance;
        participants[msg.sender] = false;
        transfer(winner, prizeAmount);
        emit WinnerPicked(winner, prizeAmount);
        return true;
    }

    function resetLottery() public onlyManager {
        if (!participants[msg.sender]) {
            emit NoParticipantsError();
            return;
        }
        participants = map(address => false);
        emit LotteryReset();
    }

    event WinnerPicked(address winner, uint256 prizeAmount);
    event NoParticipantsError();
    event LotteryReset();
}