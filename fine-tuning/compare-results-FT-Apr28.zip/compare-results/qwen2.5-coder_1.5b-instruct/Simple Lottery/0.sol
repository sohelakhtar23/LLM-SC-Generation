// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract Lottery {
    address public owner;
    mapping(address => bool) public participants;
    uint256 public ticketPrice;
    uint256 public prizeAmount;
    address public winner;
    event WinnerPicked(address indexed winner, uint256 prize);

    constructor(uint256 _ticketPrice, uint256 _prizeAmount) {
        owner = msg.sender;
        ticketPrice = _ticketPrice;
        prizeAmount = _prizeAmount;
    }

    function enterLottery() public payable {
        require(msg.value == ticketPrice, "Invalid ticket price");
        participants[msg.sender] = true;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Only the owner can call this function");
        _;
    }

    function pickWinner() public onlyOwner {
        require(participants.length > 0, "No participants have entered");

        uint256 randomIndex = uint256(blockhash(block.number - 1)) % participants.length;
        winner = participants[randomIndex];
        participants[winner] = false;

        emit WinnerPicked(winner, prizeAmount);
    }

    function resetLottery() public onlyOwner {
        for (address participant in participants) {
            if (participants[participant]) {
                participants[participant] = false;
            }
        }
    }
}