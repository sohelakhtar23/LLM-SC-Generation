// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract Lottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address public winner;
    uint256 public prizeAmount;

    constructor(uint256 _ticketPrice) {
        require(_ticketPrice > 0, "Ticket price must be greater than zero");
        manager = msg.sender;
        ticketPrice = _ticketPrice;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Invalid ticket price");
        participants[msg.sender] = true;
    }

    function pickWinner() public onlyManager {
        require(participants.length > 0, "No participants have entered the lottery");

        uint256 randomIndex = uint256(block.timestamp) % participants.length;
        winner = participants[randomIndex];
        prizeAmount = address(this).balance;

        emit WinnerPicked(winner, prizeAmount);

        // Reset participants list
        participants = map(address => false);
    }

    modifier onlyManager() {
        require(msg.sender == manager, "Only the manager can call this function");
        _;
    }

    event WinnerPicked(address winner, uint256 prizeAmount);
}