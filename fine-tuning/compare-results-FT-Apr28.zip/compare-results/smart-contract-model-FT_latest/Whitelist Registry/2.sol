// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    mapping(address => bool) private _whitelist;
    address public owner;
    
    event AddressAdded(address indexed addr);
    event AddressRemoved(address indexed addr);

    constructor() {
        require(msg.sender != address(0), "Deployer cannot be zero address");
        owner = msg.sender;
    }
    
    modifier onlyOwner() {
        require(_msgSender() == owner, "Only owner can call this function");
        _;
    }
    
    function addAddressToWhitelist(address addr) external onlyOwner {
        require(addr != address(0), "Zero address is not allowed");
        require(!_whitelist[addr], "Address already whitelisted");
        
        _whitelist[addr] = true;
        emit AddressAdded(addr);
    }
    
    function removeAddressFromWhitelist(address addr) external onlyOwner {
        require(_msgSender() == owner, "Only owner can call this function");
        require(_whitelist[addr], "Address not whitelisted");
        
        _whitelist[addr] = false;
        emit AddressRemoved(addr);
    }
    
    function isAddressWhitelisted(address addr) external view returns (bool) {
        return _whitelist[addr];
    }
}