// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract WhitelistRegistry {
    mapping(address => bool) private _whitelist;
    address public owner;
    
    event AddressAdded(address indexed addr);
    event AddressRemoved(address indexed addr);

    constructor() {
        owner = msg.sender;
    }
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Not the owner");
        _;
    }
    
    function addAddressToWhitelist(address addr) external onlyOwner {
        require(addr != address(0), "Zero address");
        require(!_whitelist[addr], "Already whitelisted");
        
        _whitelist[addr] = true;
        emit AddressAdded(addr);
    }
    
    function removeAddressFromWhitelist(address addr) external onlyOwner {
        require(_whitelist[addr], "Not whitelisted");
        
        _whitelist[addr] = false;
        emit AddressRemoved(addr);
    }
}