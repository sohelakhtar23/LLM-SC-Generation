// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SimpleLottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address[] public winners;
    bool public hasWinner;

    event EnteredLottery(address indexed participant);
    event WinnerPicked(address indexed winner);

    constructor() {
        require(msg.sender != address(0), "Manager cannot be zero address");
        manager = msg.sender;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Incorrect ether amount");
        require(!participants[msg.sender], "Already entered");
        participants[msg.sender] = true;
        emit EnteredLottery(msg.sender);
    }

    function pickWinner() public {
        require(msg.sender == manager, "Only manager can call this function");
        require(winners.length > 0, "No participants");

        uint256 randomIndex = uint256(keccak256(block.timestamp)));
        uint256 winnerCount = winners.length;
        uint256 randomParticipantIndex = randomIndex % winnerCount;

        address winnerAddress = winners[randomParticipantIndex];
        require(participants[winnerAddress], "Winner not found");

        uint256 amountToTransfer = this.balance;
        require(amountToTransfer > 0, "No funds to transfer");
        require(address(this).balance >= amountToTransfer, "Insufficient contract balance");

        (bool success,) = winnerAddress.call{value: amountToTransfer}("");
        require(success, "Transfer failed");

        winners = new address[](0);
        hasWinner = false;
        emit WinnerPicked(winnerAddress);
    }

    function withdraw() public {
        require(msg.sender == manager, "Only manager can call this function");
        uint256 balance = address(this).balance;
        require(balance > 0, "No funds to withdraw");

        (bool success,) = msg.sender.call{value: balance}("");
        require(success, "Withdrawal failed");

        hasWinner = false;
    }
}