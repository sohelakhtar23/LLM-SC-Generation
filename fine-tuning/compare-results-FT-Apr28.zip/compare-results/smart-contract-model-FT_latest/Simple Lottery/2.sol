// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SimpleLottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address[] public winners;
    bool public hasWinner;

    event EnteredLottery(address indexed winner, uint256 amount);
    event WinnerPicked(address indexed winner);

    constructor() {
        require(msg.sender != address(0), "Manager cannot be zero address");
        manager = msg.sender;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Incorrect ether value");
        require(!participants[msg.sender], "Already entered");

        participants[msg.sender] = true;
        emit EnteredLottery(msg.sender, msg.value);
    }

    function pickWinner() public {
        require(msg.sender == manager, "Only the manager can call this function");
        require(winners.length > 0, "No participants found");

        uint256 randomIndex = getRandomNumber();
        address winner = winners[randomIndex];
        winners[randomIndex] = winners[winners.length - 1];
        winners.pop();

        hasWinner = true;
        payable(winner).transfer(this.balance);
        emit WinnerPicked(winner);
    }

    function getRandomNumber() public view returns (uint256) {
        return uint256(keccak256(abi.encodePacked(block.timestamp, block.number))) % winners.length;
    }
}