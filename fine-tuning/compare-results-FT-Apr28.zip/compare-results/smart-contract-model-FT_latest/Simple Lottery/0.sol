// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SimpleLottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address public winner;
    bool public hasWinner;

    event EnteredLottery(address indexed player);
    event WinnerPicked(address indexed winner);

    constructor() {
        require(msg.sender != address(0), "Deployer cannot be the manager");
        manager = msg.sender;
        ticketPrice = 1 ether; // Fixed Ether price for simplicity
    }

    function enterLottery() public payable {
        require(msg.value == ticketPrice, "Incorrect Ether amount");
        require(!participants[msg.sender], "Already entered");
        participants[msg.sender] = true;
        emit EnteredLottery(msg.sender);
    }

    modifier onlyManager() {
        require(msg.sender == manager, "Not the manager");
        _;
    }

    function pickWinner() public payable onlyManager {
        require(hasWinner, "No winner yet");
        require(address(this).balance > 0, "No funds to distribute");

        uint256 randomNum = block.timestamp % participants.length;
        winner = participants.keys[randomNum];
        hasWinner = false;

        (bool success,) = winner.call{value: address(this).balance}("");
        require(success, "Transfer failed");
        emit WinnerPicked(winner);
    }

    function withdraw() public payable onlyManager {
        require(address(this).balance > 0, "No funds to withdraw");

        uint256 balance = address(this).balance;
        (bool success,) = manager.call{value: balance}("");
        require(success, "Transfer failed");
    }
}