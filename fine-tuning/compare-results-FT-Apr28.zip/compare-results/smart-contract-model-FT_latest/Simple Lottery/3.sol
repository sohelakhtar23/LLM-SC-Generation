// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SimpleLottery {
    address public manager;
    uint256 public ticketPrice;
    mapping(address => bool) public participants;
    address public winner;
    bool public hasWinner;

    event EnteredLottery(address indexed player, uint256 amount);
    event WinnerPicked(address indexed winner);

    constructor() {
        require(msg.sender != address(0), "Manager cannot be zero address");
        manager = msg.sender;
    }

    function enterLottery() external payable {
        require(msg.value == ticketPrice, "Incorrect ether value");
        require(!participants[msg.sender], "Already entered");

        participants[msg.sender] = true;
        emit EnteredLottery(msg.sender, msg.value);
    }

    function pickWinner() public {
        require(msg.sender == manager, "Only the manager can call this function");
        require(!hasWinner, "A winner has already been picked");
        require(participants.length > 0, "No participants have entered");

        uint256 randomIndex = uint256(keccak256(block.timestamp, block.number)) % participants.length;
        winner = address(participants[randomIndex]);
        hasWinner = true;

        uint256 amount = address(this).balance;
        (bool success,) = winner.call{value: amount}("");
        require(success, "Transfer to winner failed");

        delete participants[winner];
        emit WinnerPicked(winner);
    }
}