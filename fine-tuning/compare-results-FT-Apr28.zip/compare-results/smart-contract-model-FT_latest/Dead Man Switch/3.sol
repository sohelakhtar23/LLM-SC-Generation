// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool private locked;
    mapping(address => uint256) private lastCheckIn;
    
    event CheckIn(address indexed user, uint256 timestamp);
    event Deposit(address indexed from, uint256 amount);
    event Claim(address indexed to, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");
        
        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }
    
    receive() external payable {
        emit Deposit(msg.sender, msg.value);
    }
    
    function checkIn() public {
        require(!locked, "Contract is locked");
        lastCheckIn[msg.sender] = block.timestamp;
        emit CheckIn(msg.sender, lastCheckIn[msg.sender]);
    }
    
    function claim() public {
        require(locked, "Contract is not locked");
        
        uint256 amount = address(this).balance;
        require(amount > 0, "No funds to withdraw");
        
        address payable recipient = payable(beneficiary);
        (bool success, ) = recipient.call{value: amount}("");
        require(success, "Transfer failed");
        
        locked = true;
        emit Claim(recipient, amount);
    }
    
    modifier onlyOwner() {
        require(msg.sender == beneficiary, "Not owner");
        _;
    }
}