// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool private locked;
    event CheckIn(address indexed user, uint256 timestamp);
    event Deposit(address indexed from, uint256 amount);
    event Claim(address indexed to, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");

        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }

    receive() external payable {}

    function checkIn() public {
        require(!locked, "Contract is locked");
        uint256 timestamp = block.timestamp;
        emit CheckIn(msg.sender, timestamp);
    }

    function deposit() public payable {
        require(beneficiary != address(0), "Beneficiary cannot be zero address");
        require(block.timestamp > inactivityTimeout + timestamp, "Claim not yet due");

        locked = true;
        emit Deposit(msg.sender, msg.value);
    }

    function claim() public {
        require(!locked, "Contract is locked");
        uint256 timestamp = block.timestamp;

        if (timestamp < inactivityTimeout + timestamp) {
            revert("Claim not yet due");
        }

        locked = false;
        payable(beneficiary).transfer(address(this).balance);
        emit Claim(beneficiary, address(this).balance);
    }
}