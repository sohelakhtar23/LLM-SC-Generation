// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool private locked;
    mapping(address => uint256) private lastCheckInTimestamps;
    
    event CheckIn(address indexed user, uint256 timestamp);
    event Deposit(address indexed from, uint256 amount);
    event Claim(address indexed to, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");
        
        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }
    
    receive() external payable {
        emit Deposit(msg.sender, msg.value);
    }
    
    function checkIn() public {
        require(!locked, "Contract is locked");
        lastCheckInTimestamps[msg.sender] = block.timestamp;
        emit CheckIn(msg.sender, lastCheckInTimestamps[msg.sender]);
    }
    
    function claim() public {
        require(locked, "Contract is not locked");
        
        address sender = msg.sender;
        uint256 timestamp = lastCheckInTimestamps[sender];
        
        require(timestamp > 0, "No check-in found for this address");
        require(block.timestamp - timestamp >= inactivityTimeout, "Claim period has not elapsed");
        
        uint256 amount = address(this).balance;
        require(amount > 0, "Contract is locked");
        
        payable(beneficiary).transfer(amount);
        emit Claim(sender, amount);
    }
    
    function lock() public {
        require(msg.sender == beneficiary, "Only the beneficiary can call this function");
        locked = true;
    }
}