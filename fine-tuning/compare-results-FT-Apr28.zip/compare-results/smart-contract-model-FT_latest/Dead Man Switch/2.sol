// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DeadManSwitch {
    address public beneficiary;
    uint256 public inactivityTimeout;
    bool private locked;
    mapping(address => uint256) private lastCheckInTimestamps;
    
    event Deposit(address indexed from, uint256 amount);
    event CheckIn(address indexed owner, uint256 timestamp);
    event Claim(address indexed beneficiary, uint256 amount);

    constructor(address _beneficiary, uint256 _inactivityTimeout) {
        require(_beneficiary != address(0), "Beneficiary cannot be zero address");
        require(_inactivityTimeout > 0, "Inactivity timeout must be greater than zero");
        
        beneficiary = _beneficiary;
        inactivityTimeout = _inactivityTimeout;
    }
    
    receive() external payable {
        emit Deposit(msg.sender, msg.value);
    }
    
    function checkIn() public {
        require(!locked, "Contract is locked");
        lastCheckInTimestamps[msg.sender] = block.timestamp;
        emit CheckIn(msg.sender, block.timestamp);
    }
    
    function claim() public {
        require(locked, "Contract is not locked");
        
        address owner = msg.sender;
        uint256 timestamp = lastCheckInTimestamps[owner];
        
        if (timestamp == 0) {
            revert("Owner must call check-in before claiming");
        }
        
        uint256 durationSinceLastCheckin = block.timestamp - timestamp;
        
        require(durationSinceLastCheckin >= inactivityTimeout, "Contract is locked");
        
        payable(beneficiary).transfer(address(this).balance);
        emit Claim(beneficiary, address(this).balance);
        
        locked = true;
    }
}