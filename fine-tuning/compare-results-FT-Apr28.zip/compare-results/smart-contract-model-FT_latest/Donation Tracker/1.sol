// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    string public campaignTitle;
    
    mapping(address => uint256) public donations;
    mapping(address => bool) public hasWithdrawn;
    uint256 public totalDonations;
    uint256 public uniqueDonors;
    
    address public beneficiary = msg.sender;
    
    event Donation(address indexed donor, uint256 amount);
    event Withdrawal(address indexed to, uint256 amount);

    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
    }
    
    function donate() external payable {
        require(msg.value > 0, "Donation must be non-zero");
        
        donations[msg.sender] += msg.value;
        totalDonations += msg.value;
        uniqueDonors++;
        
        emit Donation(msg.sender, msg.value);
    }
    
    function withdraw() external {
        require(hasWithdrawn[msg.sender] == false, "Already withdrawn");
        hasWithdrawn[msg.sender] = true;
        
        uint256 amount = donations[msg.sender];
        require(amount > 0, "No funds to withdraw");
        
        (bool success,) = beneficiary.call{value: amount}("");
        require(success, "Transfer failed");
        
        emit Withdrawal(beneficiary, amount);
    }
    
    function getDonationCount() external view returns (uint256) {
        return uniqueDonors;
    }
    
    function getTotalDonations() external view returns (uint256) {
        return totalDonations;
    }
}