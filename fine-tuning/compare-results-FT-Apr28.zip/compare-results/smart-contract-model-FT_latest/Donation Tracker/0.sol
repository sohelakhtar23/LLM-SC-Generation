// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    string public campaignTitle;
    
    mapping(address => uint256) private donations;
    mapping(address => bool) private isDonator;
    uint256 public totalDonations;
    uint256 public uniqueDonators;
    
    event Donation(address indexed donor, uint256 amount);
    event Withdrawal(address indexed beneficiary, uint256 amount);
    
    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
        isDonator[msg.sender] = true;
    }
    
    function donate() public payable {
        require(msg.value > 0, "Cannot donate zero Ether");
        
        donations[msg.sender] += msg.value;
        totalDonations += msg.value;
        uniqueDonators++;
        
        emit Donation(msg.sender, msg.value);
    }
    
    function withdraw() public {
        require(isDonator[msg.sender], "Not a donor");
        uint256 amount = donations[msg.sender];
        
        require(address(this).balance >= amount, "Insufficient funds");
        
        donations[msg.sender] = 0;
        isDonator[msg.sender] = false;
        
        payable(msg.sender).transfer(amount);
        
        emit Withdrawal(msg.sender, amount);
    }
    
    function getDonationCount() public view returns (uint256) {
        return uniqueDonators;
    }
    
    function getTotalDonations() public view returns (uint256) {
        return totalDonations;
    }
}