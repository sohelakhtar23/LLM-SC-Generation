// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract DonationTracker {
    string public campaignTitle;
    uint256 public totalDonations;
    mapping(address => uint256) public donationsPerAddress;
    mapping(address => bool) private isBeneficiary;
    address public beneficiary;
    
    event Donation(address indexed donor, uint256 amount);
    event Withdrawal(address indexed to, uint256 amount);

    constructor(string memory _campaignTitle) {
        campaignTitle = _campaignTitle;
        beneficiary = msg.sender;
        isBeneficiary[beneficiary] = true;
    }
    
    receive() external payable {}
    
    function donate() public payable {
        require(isBeneficiary[msg.sender], "Only the beneficiary can donate");
        
        uint256 amount = msg.value;
        if (amount == 0) revert("Donations of zero Ether are not allowed");
        
        donationsPerAddress[msg.sender] += amount;
        totalDonations += amount;
        
        emit Donation(msg.sender, amount);
    }
    
    function withdraw() public {
        require(isBeneficiary[msg.sender], "Only the beneficiary can withdraw");
        
        uint256 amount = address(this).balance;
        if (amount == 0) revert("No funds to withdraw");
        
        payable(beneficiary).transfer(amount);
        
        emit Withdrawal(beneficiary, amount);
    }
    
    function getDonationCount() public view returns (uint256) {
        return donationsPerAddress.length;
    }
    
    function getTotalDonations() public view returns (uint256) {
        return totalDonations;
    }
}