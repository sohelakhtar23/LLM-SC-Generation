// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    uint256 public constant TOTAL_SHARES = 100;
    
    address[] public recipients;
    mapping(address => uint256) public shares;
    uint256 public totalShares;
    
    event Split(address indexed recipient, uint256 amount);
    
    modifier onlyRecipient() {
        require(recipients.contains(msg.sender), "Not a recipient");
        _;
    }
    
    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0 && _shares.length == _recipients.length, "Invalid recipients and shares");
        
        for (uint256 i = 0; i < _recipients.length; ++i) {
            address recipient = _recipients[i];
            uint256 share = _shares[i];
            
            require(recipient != address(0), "Zero address");
            require(shares[recipient] == 0, "Duplicate recipient");
            require(share > 0 && share <= TOTAL_SHARES, "Invalid share");
            
            recipients.push(recipient);
            shares[recipient] = share;
        }
        
        totalShares = _shares.reduce((a, b) => a + b, 0);
    }
    
    function split() public payable onlyRecipient {
        require(msg.value > 0, "Zero Ether");
        
        uint256 recipientIndex = (msg.sender == recipients[0]) ? 0 : recipients.indexOf(msg.sender);
        uint256 share = shares[msg.sender];
        uint256 amount = (totalShares * share) / TOTAL_SHARES;
        
        require(amount > 0, "Recipient has no share");
        
        payable(recipients[recipientIndex]).transfer(amount);
        
        emit Split(msg.sender, amount);
    }
    
    function getRecipients() public view returns (address[] memory) {
        return recipients;
    }
    
    function getShares() public view returns (uint256[] memory) {
        uint256[] memory sharesArray = new uint256[](recipients.length);
        
        for (uint256 i = 0; i < recipients.length; ++i) {
            sharesArray[i] = shares[recipients[i]];
        }
        
        return sharesArray;
    }
}