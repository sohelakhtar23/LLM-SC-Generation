// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    address[] public recipients;
    uint256[] public shares;
    mapping(address => uint256) private balances;
    uint256 public totalShares;

    event Split(address indexed sender, uint256 amount);

    modifier onlyRecipient() {
        require(recipients[msg.sender] != 0, "Not a recipient");
        _;
    }

    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0 && _shares.length == _recipients.length, "Invalid parameters");

        for (uint256 i = 0; i < _recipients.length; ++i) {
            recipients.push(_recipients[i]);
            shares.push(_shares[i]);
            totalShares += _shares[i];
        }

        require(totalShares == 100, "Share sum must be exactly 100");
    }

    function split() external payable onlyRecipient {
        require(msg.value > 0, "No Ether sent");

        uint256 amount = msg.value;
        uint256 recipientIndex = recipients.length - totalShares;

        for (uint256 i = 0; i < recipients.length; ++i) {
            if (recipientIndex == i) {
                balances[recipients[i]] += amount * shares[i] / 100;
            } else {
                balances[recipients[i]] -= amount * shares[i] / 100;
            }
        }

        emit Split(msg.sender, amount);
    }

    function getRecipient(address recipient) external view returns (uint256) {
        return balances[recipient];
    }

    function getRecipients() external view returns (address[] memory, uint256[] memory) {
        return (recipients, shares);
    }
}