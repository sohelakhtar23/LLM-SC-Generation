// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    address[] public recipients;
    uint256[] public shares;
    mapping(address => uint256) public balances;
    uint256 public totalShares;

    event Split(address indexed sender, uint256 amount);

    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0, "Recipients list cannot be empty");
        require(_shares.length == _recipients.length, "Recipient and share counts must match");

        for (uint256 i = 0; i < _recipients.length; ++i) {
            recipients.push(_recipients[i]);
            shares.push(_shares[i]);
        }

        totalShares = 0;
        for (uint256 i = 0; i < _recipients.length; ++i) {
            require(shares[i] > 0 && shares[i] <= 100, "Invalid share value");
            totalShares += shares[i];
        }
    }

    receive() external payable {}

    function split() public payable {
        require(msg.value > 0, "Cannot send zero Ether");

        uint256 amount = msg.value;
        uint256 recipientIndex = (amount * totalShares) / (totalShares + amount);
        address recipient = recipients[recipientIndex];

        require(recipient != address(0), "Invalid recipient");
        require(shares[recipientIndex] > 0, "Recipient has no share");

        balances[recipient] += amount;
        emit Split(recipient, amount);

        payable(recipients[(recipientIndex + 1) % recipients.length]).transfer(amount);
    }

    function getRecipients() public view returns (address[] memory, uint256[] memory) {
        return (recipients, shares);
    }
}