// SPDX-License-Identifier: MIT
pragma solidity ^0.8.x;

contract SplitPayment {
    address[] public recipients;
    uint256[] public shares;
    mapping(address => uint256) private balances;
    uint256 public totalShares;

    event Split(address indexed sender, uint256 amount);

    modifier onlyRecipient() {
        require(isRecipient(msg.sender), "Not a recipient");
        _;
    }

    constructor(address[] memory _recipients, uint256[] memory _shares) {
        require(_recipients.length > 0 && _shares.length == _recipients.length, "Invalid recipients and shares");

        for (uint256 i = 0; i < _recipients.length; ++i) {
            address recipient = _recipients[i];
            uint256 share = _shares[i];

            require(recipient != address(0), "Zero address");
            require(share > 0 && share <= 100, "Invalid share");

            recipients.push(recipient);
            shares.push(share);
        }

        totalShares = 0;
        for (uint256 i = 0; i < _recipients.length; ++i) {
            totalShares += shares[i];
        }
    }

    function split() external payable onlyRecipient {
        require(msg.value > 0, "No Ether sent");

        uint256 amount = msg.value;
        uint256 recipientIndex = getRecipientIndex(msg.sender);
        uint256 share = shares[recipientIndex];

        balances[msg.sender] += (amount * share) / totalShares;
        balances[recipients[recipientIndex]] -= (amount * share) / totalShares;

        emit Split(msg.sender, amount);
    }

    function isRecipient(address addr) public view returns (bool) {
        for (uint256 i = 0; i < recipients.length; ++i) {
            if (addr == recipients[i]) return true;
        }
        return false;
    }

    function getRecipientIndex(address addr) public view returns (uint256) {
        for (uint256 i = 0; i < recipients.length; ++i) {
            if (addr == recipients[i]) return i;
        }
        revert("Not a recipient");
    }

    function getBalances() external view returns (address[] memory, uint256[] memory) {
        address[] memory recipientAddresses = new address[](recipients.length);
        uint256[] memory balancesArray = new uint256[](recipients.length);

        for (uint256 i = 0; i < recipients.length; ++i) {
            recipientAddresses[i] = recipients[i];
            balancesArray[i] = balances[recipientAddresses[i]];
        }

        return (recipientAddresses, balancesArray);
    }
}